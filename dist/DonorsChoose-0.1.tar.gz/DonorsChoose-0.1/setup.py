import setuptools

setuptools.setup(
    name="DonorsChoose",
    version="0.1",
    author="Sudhanva Kulkarni",
    author_email="sudhanvaprk1@gmail.com",
    description="Donors Choose Prediction Code Package",
    package_dir={"": "src"},
    # packages=setuptools.find_packages(where="src"),
    # python_requires=">=3.8"
)